<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/* PANEL */
$locale['WIN_97'] = "<center><font size=2><b><u>site reviews:</u></b></font><p></center>";
$locale['WIN_98'] = "<center><font size=6><b>I N F O P O R T A L</b></font></center>";
$locale['WIN_99'] = "SITE-INFOS";
$locale['WIN_101'] = "LATEST NEWS";
$locale['WIN_102'] = "NEWEST PHOTOS";
$locale['WIN_103'] = "LATEST ARTICLES";
$locale['WIN_104'] = "RANDOM-PHOTO";
$locale['WIN_105'] = "LATEST FORUM THREADS";
$locale['WIN_106'] = "MOST READ THREADS";
$locale['WIN_107'] = "LATEST DOWNLOADS";
$locale['WIN_108'] = "NEWEST DOWNLOAD COMMENTS";
$locale['WIN_109'] = "NEWEST WEBLINKS";
$locale['WIN_110'] = "LATEST DOWNLOAD COMMENTS";
$locale['WIN_111'] = "show complete album...";
$locale['WIN_112'] = "no downloads available...";

/* ADMIN-AREA */
$locale['WIN_200'] = "Advanced Whats New Panel - ADMIN";
$locale['WIN_201'] = "SETTINGS";
$locale['WIN_202'] = "Show latest forumthreads";
$locale['WIN_203'] = "Show most read forumthreads";
$locale['WIN_204'] = "Show latest news";
$locale['WIN_205'] = "Show latest articles";
$locale['WIN_206'] = "Show newest comments (articles, news & own sites)";
$locale['WIN_207'] = "Show newest photos (text-plain)";
$locale['WIN_208'] = "Show newest weblinks";
$locale['WIN_209'] = "Show latest downloads";
$locale['WIN_210'] = "Show random-photo";
$locale['WIN_213'] = "Show latest downloads";
$locale['WIN_214'] = "Show latest download comments";
$locale['WIN_215'] = "Save settings";

?>