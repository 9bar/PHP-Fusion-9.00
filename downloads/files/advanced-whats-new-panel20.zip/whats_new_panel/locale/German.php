<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

/* PANEL-ANZEIGE */
$locale['WIN_97'] = "<center><font size=2><b><u>AKTUELLES AUF DER SEITE IM &Uuml;BERBLICK:</u></b></font><p></center>";
$locale['WIN_98'] = "<center><font size=6><b>I N F O P O R T A L</b></font></center>";
$locale['WIN_99'] = "SITE-INFOS";
$locale['WIN_101'] = "AKTUELLE NEWS";
$locale['WIN_102'] = "AKTUELLSTE FOTOS";
$locale['WIN_103'] = "AKTUELLE ARTIKEL";
$locale['WIN_104'] = "AUS DEN GALLERIEN";
$locale['WIN_104'] = "ZUFALLSFOTO";
$locale['WIN_105'] = "FORUM-BEITR&Auml;GE";
$locale['WIN_106'] = "FORUM-BEITR&Auml;GE - HITS";
$locale['WIN_107'] = "DOWNLOADS";
$locale['WIN_108'] = "KOMMENTARE";
$locale['WIN_109'] = "LINKS";
$locale['WIN_110'] = "DOWNLOADS - KOMMENTARE";
$locale['WIN_111'] = "komplettes Album anzeigen...";
$locale['WIN_112'] = "keine Downloads vorhanden...";

/* ADMIN-BEREICH */
$locale['WIN_200'] = "Advanced Whats New Panel - ADMIN";
$locale['WIN_201'] = "EINSTELLUNGEN";
$locale['WIN_202'] = "Anzeige der neuesten Forumthreads";
$locale['WIN_203'] = "Anzeige der meist gelesenen Forumthreads";
$locale['WIN_204'] = "Anzeige der aktuellsten News";
$locale['WIN_205'] = "Anzeige der neuesten Artikel";
$locale['WIN_206'] = "Anzeige der letzten Kommentare (Artikel, News und Eigene Seiten)";
$locale['WIN_207'] = "Anzeige der neuesten Fotos (nur Text!)";
$locale['WIN_208'] = "Anzeige der letzten Weblinks";
$locale['WIN_209'] = "Anzeige der neuesten Downloads";
$locale['WIN_210'] = "Anzeige eines Zufallsfotos aus der Gallerie";
$locale['WIN_211'] = "Professional-Download-Panel";
$locale['WIN_212'] = "Werden hier die Haken gesetzt, werden die entsprechenden Informationen aus<br>dem Professional-Download-Panel angezeigt";
$locale['WIN_213'] = "Anzeige der neuesten Downloads";
$locale['WIN_214'] = "Anzeige der letzten Kommentare aus den Downloads";
$locale['WIN_215'] = "Einstellungen speichern";
?>