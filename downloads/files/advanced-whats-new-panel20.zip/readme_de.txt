==========================================
=     Advanded Whats New Panel 2.0
=     optimiert f�r PHP-Fusion v.7
==========================================
= (c) 2011 by @ster
= m@il: webmaster@edsterathome.de
= web: www.edsterathome.de
==========================================

WAS MACHT DAS PANEL?
--------------------
Es zeigt aus den wichtigsten, standardm��ig in PHP-Fusion 
enthaltenen Funktionen die jeweils letzten drei Beitr�ge 
an (z.B. News, Artikel, Fotos, Kommentare, ...).

Das Advanced Whats New Panel 2.0 wurde unter der
aktuellen PHP-Fusion Version 7.01.04 installiert und getestet 
und lief ohne Probleme.

INSTALLATION:
-------------
1. Lade das Verzeichnis "whats_new_panel" in das
   "infusions"-Verzeichnis.

2. Log dich auf der Homepage als Super-Admin ein und
   installiere die Infusion �ber:
   System Admin >> Infusionen
   
3. Das Panel wird automatisch in der Panel-Administration
   eingef�gt, ist aber nach der Installation der
   Infusion zun�chst deaktiviert. Das Panel installiert
   sich i.d.R. in der "Mitte h�her".

4. Einstellungen, was im Panel angezeigt werden soll,
   ist zu finden im Admin-Bereich unter:
   "Infusionen"...
   (standardm��ig rechts oben zu finden)

Das Panel darf nach Belieben angepasst und/oder ver�ndert werden.
Es w�re sch�n, wenn bei Ver�nderungen des Panels der Copyright
Hinweis in den PHP-Files bestehen bleiben w�rde.

Ansonsten w�nsche ich euch viel Spa� damit!

Gr��e aus dem sch�nen Saarland
@ster