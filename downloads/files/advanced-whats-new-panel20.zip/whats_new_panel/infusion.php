<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/
if(!defined('IN_FUSION') || !checkrights('I')) {
	die;
}


// Sprachdatei pr�fen
if(file_exists(INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php"))
{include INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php";}
else{include INFUSIONS."whats_new_panel/locale/English.php";}

$inf_title = "Advanced Whats-New-Panel";
$inf_description = "Advanced Whats New Panel f�r PHP-Fusion v7";
$inf_version = "2.0";
$inf_developer = "@ster";
$inf_email = "webmaster@edsterathome.de";
$inf_weburl = "http://www.edsterathome.de";

$inf_folder = "whats_new_panel";
$inf_link_name = $inf_title;
$inf_link_url = "whats_new_panel.php";
//$inf_admin_image = "infusions.gif";
//$inf_admin_panel = "admin/panel_settings.php";



$inf_newtable[1] = DB_PREFIX."whatsnewpanel_settings (

  `id` smallint(5) unsigned NOT NULL auto_increment, 
  `latest_forumthreads` tinyint(1) unsigned NOT NULL default '1', 
  `most_read_forumthreads` tinyint(1) unsigned NOT NULL default '1', 
  `latest_news` tinyint(1) unsigned NOT NULL default '1', 
  `latest_articles` tinyint(1) unsigned NOT NULL default '1', 
  `latest_comments` tinyint(1) unsigned NOT NULL default '1', 
  `latest_photos` tinyint(1) unsigned NOT NULL default '1', 
  `latest_weblinks` tinyint(1) unsigned NOT NULL default '1', 
  `latest_fusiondownloads` tinyint(1) unsigned NOT NULL default '1', 
  `random_photo` tinyint(1) unsigned NOT NULL default '1', 
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci AUTO_INCREMENT=1 ;";

$inf_adminpanel[1] = array(
	"title" => "Advanced Whats New Panel",
	"image" => "infusion_panel.gif",
	"panel" => "admin/panel_settings.php",
	"rights" => "TH2"
);

$inf_insertdbrow[1] = DB_PREFIX."whatsnewpanel_settings (id, latest_forumthreads, most_read_forumthreads, latest_news,latest_articles, latest_comments, latest_photos, latest_weblinks, latest_fusiondownloads, random_photo) VALUES ('1', '1', '1', '1', '1', '1', '1', '1', '1', '1')";

$inf_droptable[1] = DB_PREFIX."whatsnewpanel_settings";

?>

