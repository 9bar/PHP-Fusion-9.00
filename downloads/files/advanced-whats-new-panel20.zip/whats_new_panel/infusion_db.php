<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined("IN_FUSION")) { die("Access Denied"); }

if (!defined("DB_INFUSION_TABLE")) {
	define("DB_INFUSION_TABLE", DB_PREFIX."infusion_table");
}
?>