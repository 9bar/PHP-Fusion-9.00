<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined("IN_FUSION")) { die("Access Denied"); }

//---------------------------
// Einbinden der locale-Datei
//---------------------------
$sprache = $settings['locale'];
if (file_exists(INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php")) {
	include INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php";
} else {
	include INFUSIONS."whats_new_panel/locale/English.php";
}


opentable($locale['WIN_99']);

// ----------------------------------------
// �berschrift des Advanced-Whats-New-Panel
// ----------------------------------------
echo "<center>".$settings['sitename']."</center><br>";
echo "".$locale['WIN_98']."<br>";
echo "".$locale['WIN_97']."<p><br><p>";
// Ende der �berschrift

$panel_settings = dbquery("SELECT * FROM ".$db_prefix."whatsnewpanel_settings WHERE id='1'");
$panel_data = dbarray($panel_settings);



			/* HAUPTTABELLE - �FFNEN */
			echo "<table width='100%' cellpadding='0' cellspacing='0' align='center'>";
			echo "<tr>";
			echo "<td>";
			echo "<table width='100%' cellspacing='0' cellpadding='0'>";
			echo "<tr>";


/*---------------
AKTUELLSTEN NEWS
---------------*/
if ($panel_data['latest_news'] == "1")
{
echo "<td valign='top'>";
echo "<p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_101']."</span>";

$result = dbquery("SELECT * FROM ".$db_prefix."news ORDER BY news_datestamp DESC LIMIT 0,3");

	if (dbrows($result) != 0)
	{
	while($data = dbarray($result))
	{
	$itemsubject = trimlink($data['news_subject'], 25);
	$news_id = ($data['news_id']);
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a href='".BASEDIR."news.php?readmore=$news_id' title='".$data['news_subject']."'>".$itemsubject."</a>";
	}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
	echo "</td>";
}			


/*-------------------------------------
AKTUELLSTEN ARTIKEL/BEITR�GE angezeigt
-------------------------------------*/
if ($panel_data['latest_articles'] == "1")
{
echo "<td valign='top'>";
echo "<p><p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_103']."</span>";

$result = dbquery("SELECT * FROM ".$db_prefix."articles ORDER BY article_datestamp DESC LIMIT 0,3");

	if (dbrows($result) != 0)
	{
	while($data = dbarray($result))
	{
	$itemsubject = trimlink($data['article_subject'], 25);
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a href='".BASEDIR."readarticle.php?article_id=".$data['article_id']."' title='".$data['article_subject']."' >".$itemsubject."</a>\n";
	}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
echo "</td>";
}


/*----------
ZUFALLSFOTO
----------*/
if ($panel_data['random_photo'] == "1")
{
echo "<td valign='top'>";

	echo "<table width='100%' cellpadding='0' cellspacing='0'>";
	echo "<tr>";
	echo "<td valign='top'>";
	echo "<div style='text-align:center'>";
	echo "<span class='alt' style='font-weight:bold'>".$locale['WIN_104']."</span><br>";

	$result = dbquery("SELECT ta.album_id,album_title,photo_id,photo_thumb1,photo_title FROM ".$db_prefix."photo_albums ta JOIN ".$db_prefix."photos USING (album_id) ORDER BY RAND() LIMIT 1");

		if (dbrows($result)==1)
		{
		$data = dbarray($result);
		$filename = PHOTOS.$data['photo_thumb1'];
		$fotoname = trimlink($data['photo_title'], 15);
		if (!file_exists($filename))$filename=IMAGES."/imagenotfound.jpg";
		echo "<div style='text-align:center'>";
		echo "<a href='".BASEDIR."photogallery.php?photo_id=".$data['photo_id']."' class='gallery'>";
		echo "<img src='".PHOTOS."album_".$data['album_id']."/".$data['photo_thumb1']."' title='".$data['photo_title']."' alt='".$data['photo_title']."'></a>";
		/*
		echo "<br>";
		echo "<a href='".BASEDIR."photogallery.php?photo_id=".$data['photo_id']."' title='".$data['photo_title']."'>".$fotoname."</a>";
		echo "<br>";
		echo "<a href='".BASEDIR."photogallery.php?album_id=".$data['album_id']."' title='".$locale['WIN_111']."'>".$data['album_title']."</a>";
		*/
		echo "</div>";
		}
		echo "</td>";
		echo "</tr>";
		echo "</table>";

echo "</td>";
}



			/* HAUPTTABELLE? */
			echo "</tr>";
			echo "<tr>";


/*------------------------------------------------
AKTUELLSTEN FOREN-BEITR�GE
------------------------------------------------*/
if ($panel_data['latest_forumthreads'] == "1")
{
echo "<td valign='top'>";
echo "<p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_105']."</span><br>";

$result = dbquery("	SELECT tt.forum_id, tt.thread_id, tt.thread_subject, tt.thread_lastpost FROM ".DB_THREADS." tt	INNER JOIN ".DB_FORUMS." tf ON tt.forum_id=tf.forum_id	WHERE ".groupaccess('tf.forum_access')." AND tt.thread_hidden='0'	ORDER BY thread_lastpost DESC LIMIT 3	");

	if (dbrows($result) != 0)
	{
		while($data = dbarray($result))
		{
		$itemsubject = trimlink($data['thread_subject'], 25);
		//echo "<img src='".THEME."images/bullet.gif'> <a href='".FORUM."viewthread.php?".$rstart."forum_id=".$data['forum_id']."&thread_id=".$data['thread_id']."' title='".$data['thread_subject']."' >$itemsubject</a><br>";
		echo THEME_BULLET." <a href='".FORUM."viewthread.php?thread_id=".$data['thread_id']."' title='".$data['thread_subject']."' class='side'>$itemsubject</a><br />\n";
		}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
	echo "</td>";
}



/*------------------------------
MEIST GELESENE FORUM-BEITR�GE
------------------------------*/
if ($panel_data['most_read_forumthreads'] == "1")
{
echo "<td valign='top'>";
echo "<p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_106']."</span>";

$result = dbquery("SELECT tf.forum_id, tt.thread_id, tt.thread_subject, COUNT(tp.post_id) as count_posts FROM ".$db_prefix."forums tf INNER JOIN ".$db_prefix."threads tt USING(forum_id) INNER JOIN ".$db_prefix."posts tp USING(thread_id) WHERE ".groupaccess('forum_access')." GROUP BY thread_id ORDER BY count_posts DESC, thread_lastpost DESC LIMIT 3");

	if (dbrows($result) != 0)
	{
	while($data = dbarray($result))
	{
	$itemsubject = trimlink($data['thread_subject'], 25);
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a  href='".FORUM."viewthread.php?forum_id=".$data['forum_id']."&thread_id=".$data['thread_id']."' title='".$data['thread_subject']."' >$itemsubject</a>\n";
	}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
	echo "</td>";
}


	
/*-----------------
AKTUELLSTEN FOTOS
-----------------*/
if ($panel_data['latest_photos'] == "1")
{
echo "<td valign='top'>";
echo "<p><p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_102']."</span>";

$result = dbquery("SELECT * FROM ".$db_prefix."photos ORDER BY photo_id DESC LIMIT 0,3");

	if (dbrows($result) != 0)
	{
	while($data = dbarray($result))
	{
	$itemsubject = trimlink($data['photo_id'], 25);
	$itemdescription = trimlink($data['photo_title'], 25);
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a href='".BASEDIR."photogallery.php?photo_id=".$data['photo_id']."' title='".$data['photo_title']."' >".$itemdescription."</a>";
	}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
	echo "</td>";
}


			/* HAUPTTABELLE */
			echo "</tr>";
			echo "<tr>";


/*--------------------
AKTUELLSTEN WEBLINKS
--------------------*/
if ($panel_data['latest_weblinks'] == "1")
{
	echo "<td valign='top'>";
	echo "<p><p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_109']."</span>";
	
	$result = dbquery("SELECT * FROM ".$db_prefix."weblinks ORDER BY weblink_datestamp DESC LIMIT 0,3");
	
		if (dbrows($result) != 0)
		{
		while($data = dbarray($result))
		{
		$itemname = trimlink($data['weblink_name'], 30);
		$cat_id = ($data['weblink_cat']);
		echo "<br>
		<img border='0' src='".THEME."images/bullet.gif'>
		<a target='_blank' href='".BASEDIR."weblinks.php?cat_id=".$data['weblink_cat']."&amp;weblink_id=".$data['weblink_id']."' title='".$data['weblink_name']."'>".$itemname."</a>";
		}
		echo "</p>";
		}
		else
		{
		echo "<div style='text-align:left'>".$locale['004']."</div>\n";
		}
		
	echo "</td>";
}



/*---------------------
AKTUELLSTEN KOMMENTARE
---------------------*/
if ($panel_data['latest_comments'] == "1")
{
echo "<td valign='top'>";
echo "<p><p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_108']."</span>";

$result = dbquery("SELECT * FROM ".$db_prefix."comments ORDER BY comment_datestamp DESC LIMIT 0,3");

	if (dbrows($result) != 0)
	{
	while($data = dbarray($result))
	{
	$itemsubject = trimlink($data['comment_message'], 25);
	if ($data['comment_type'] == "P")
	{
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a href='".BASEDIR."photogallery.php?photo_id=".$data['comment_item_id']."' target='_self'>".trimlink($data['comment_message'], 30)."</a>";
	}
	else if ($data['comment_type'] == "A")
	{
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a target='_self' href='".BASEDIR."readarticle.php?article_id=".$data['comment_item_id']."'>".trimlink($data['comment_message'], 30)."</a>";
	}
	else if ($data['comment_type'] == "N")
	{
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a target='_self' href='".BASEDIR."news.php?readmore=".$data['comment_item_id']."'>".trimlink($data['comment_message'], 30)."</a>";
	}
	else if ($data['comment_type'] == "C")
	{
	echo "<br>
	<img border='0' src='".THEME."images/bullet.gif'>
	<a target='_self' href='".BASEDIR."viewpage.php?page_id=".$data['comment_item_id']."'>".trimlink($data['comment_message'], 30)."</a>";
	}
	
	}
	echo "</p>";
	}
	else
	{
	echo "<div style='text-align:left'>".$locale['004']."</div>\n";
	}
	echo "</td>";
}


/* -----------------------------------------------------
AKTUELLSTEN DOWNLOADS (PHP-Fusion integrierte Downloads)
------------------------------------------------------*/
if ($panel_data['latest_fusiondownloads'] == "1")
{
echo "<td valign='top'>";
echo "<p><p style='text-align:left'><span class='alt' style='font-weight:bold'>".$locale['WIN_107']."</span>";
	
	$result = dbquery("SELECT * FROM ".$db_prefix."downloads ORDER BY download_datestamp DESC LIMIT 0,3");
	
		if (dbrows($result) != 0)
		{
			while($data = dbarray($result))
			{
			$itemsubject = trimlink($data['download_title'], 30);
			$cat_id = ($data['download_cat']);
			echo "<br>
			<img border='0' src='".THEME."images/bullet.gif'>
			<a href='".BASEDIR."downloads.php?cat_id=$cat_id&download_id=".$data['download_id']."' title='".$data['download_title']."' target='_blank'>".$itemsubject."</a>";
			}
 		echo "</p>";
		}
		else
		{
		echo "<div style='text-align:left'>".$locale['WIN_112']."</div>\n";
		}
		echo "</td>";
	}


	
echo "</tr>";
echo "</table>";



			/* HAUPTTABELLE - SCHLIESSEN */
			echo "</td>";
			echo "</tr>";
			echo "</table>";



closetable();


?>