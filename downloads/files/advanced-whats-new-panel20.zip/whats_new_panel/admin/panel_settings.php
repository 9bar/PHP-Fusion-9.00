<?php
/*
*
* @ADVANCED WHATS NEW PANEL - core7
* @version 2.0
* @copyright (c) 2011 @ster <webmaster@edsterathome.de>
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

require_once "../../../maincore.php";
require_once THEMES."templates/admin_header.php";

// Zugriffsrechte pr�fen
// if(!checkRights("IP")) {fallback("../error.php");}
if (!checkRights("S")) { header("Location:../index.php"); exit; }

//---------------------------
// Einbinden der locale-Datei
//---------------------------
if (file_exists(INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php")) {
	include INFUSIONS."whats_new_panel/locale/".$settings['locale'].".php";
} else {
	include INFUSIONS."whats_new_panel/locale/English.php";
}

//---------------------------
//Speichern der Einstellungen
//---------------------------
if (isset ($_POST['save_settings']))
{
	if (isset ($_POST['show_latest_forumthreads']) == "yes")
	{$save_latest_forumthreads = "1";}else{$save_latest_forumthreads = "0";}
	if (isset ($_POST['show_most_read_forumthreads']) == 'yes')
	{$save_most_read_forumthreads = "1";}else{$save_most_read_forumthreads = "0";}
	if (isset ($_POST['show_latest_news']) == 'yes')
	{$save_latest_news = "1";}else{$save_latest_news = "0";}
	if (isset ($_POST['show_latest_articles']) == 'yes')
	{$save_latest_articles = "1";}else{$save_latest_articles = "0";}
	if (isset ($_POST['show_latest_comments']) == 'yes')
	{$save_latest_comments = "1";}else{$save_latest_comments = "0";}
	if (isset ($_POST['show_latest_photos']) == 'yes')
	{$save_latest_photos = "1";}else{$save_latest_photos = "0";}
	if (isset ($_POST['show_latest_weblinks']) == 'yes')
	{$save_latest_weblinks = "1";}else{$save_latest_weblinks = "0";}
	//if ($show_latest_prodownloads == 'yes')
	//{$save_latest_prodownloads = "1";}else{$save_latest_prodownloads = "0";}
	//if ($show_latest_prodownload_comments == 'yes')
	//{$save_latest_prodownload_comments = "1";}else{$save_latest_prodownload_comments = "0";}
	if (isset ($_POST['show_latest_fusiondownloads']) == 'yes')
	{$save_latest_fusiondownloads = "1";}else{$save_latest_fusiondownloads = "0";}
	if (isset ($_POST['show_random_photo']) == 'yes')
	{$save_random_photo = "1";}else{$save_random_photo = "0";}

	$save_settings = dbquery("UPDATE ".$db_prefix."whatsnewpanel_settings SET latest_forumthreads='$save_latest_forumthreads', "
					."most_read_forumthreads='$save_most_read_forumthreads', latest_news='$save_latest_news', latest_articles='$save_latest_articles', "
					."latest_comments='$save_latest_comments', latest_photos='$save_latest_photos', latest_weblinks='$save_latest_weblinks', "
					."latest_fusiondownloads='$save_latest_fusiondownloads', random_photo='$save_random_photo' "
					."WHERE id='1'");
}




opentable($locale['WIN_200']);

$result = dbquery("SELECT * FROM ".$db_prefix."whatsnewpanel_settings WHERE id='1'");


echo "<table width='40%' class='tbl-border' cellpadding='0' cellspacing='1'>";
echo "<form name='selectform' method='post' action='".FUSION_SELF."'>";

while ($data = dbarray($result))
{
	$show_latest_forumthreads = $data['latest_forumthreads'] == "1" ? " checked" : "";
	$show_most_read_forumthreads = $data['most_read_forumthreads'] == "1" ? " checked" : "";
	$show_latest_news = $data['latest_news'] == "1" ? " checked" : "";
	$show_latest_articles = $data['latest_articles'] == "1" ? " checked" : "";
	$show_latest_comments = $data['latest_comments'] == "1" ? " checked" : "";
	$show_latest_photos = $data['latest_photos'] == "1" ? " checked" : "";
	$show_latest_weblinks = $data['latest_weblinks'] == "1" ? " checked" : "";
	//$show_latest_prodownloads = $data['latest_prodownloads'] == "1" ? " checked" : "";
	//$show_latest_prodownload_comments = $data['latest_prodownload_comments'] == "1" ? " checked" : "";
	$show_latest_fusiondownloads = $data['latest_fusiondownloads'] == "1" ? " checked" : "";
	$show_random_photo = $data['random_photo'] == "1" ? " checked" : "";

	echo "<tr>";
	echo "<td class='tbl1' align='center' colspan='2'><font size='2'><b>".$locale['WIN_201']."</b></font></td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_forumthreads' value='yes'$show_latest_forumthreads>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_202']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_most_read_forumthreads' value='yes'$show_most_read_forumthreads>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_203']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_news' value='yes'$show_latest_news>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_204']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_articles' value='yes'$show_latest_articles>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_205']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_comments' value='yes'$show_latest_comments>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_206']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_photos' value='yes'$show_latest_photos>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_207']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_weblinks' value='yes'$show_latest_weblinks>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_208']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_latest_fusiondownloads' value='yes'$show_latest_fusiondownloads>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_209']."";
	echo "</td>";
	echo "</tr>";

	echo "<tr>";
	echo "<td width='5%' align='center' class='tbl1'>";
	echo "<input type='checkbox' name='show_random_photo' value='yes'$show_random_photo>";
	echo "</td>";
	echo "<td class='tbl2'>";
	echo "".$locale['WIN_210']."";
	echo "</td>";
	echo "</tr>";
}

echo "<tr>";
echo "<td colspan='2' align='center'>";
echo "<input type='submit' name='save_settings' value='".$locale['WIN_215']."' class='button'>";
echo "</td>";
echo "</tr>";

echo "</form>";
echo "</table>";



closetable();

require_once THEMES."templates/footer.php";

?>